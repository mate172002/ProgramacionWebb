import React, { useState } from 'react';

const FormularioEstudiante = ({ addEstudiante }) => {
  const [nombre, setNombre] = useState('');
  const [edad, setEdad] = useState('');
  const [ciclo, setCiclo] = useState('');
  const [carrera, setCarrera] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (nombre && edad && ciclo && carrera) {
      addEstudiante({ nombre, edad, ciclo, carrera });
      setNombre('');
      setEdad('');
      setCiclo('');
      setCarrera('');
    }
  };

  return (
    <form onSubmit={handleSubmit} style={{ marginBottom: '20px' }}>
      <input
        type="text"
        placeholder="Nombre"
        value={nombre}
        onChange={(e) => setNombre(e.target.value)}
        style={{ marginRight: '10px' }}
      />
      <input
        type="number"
        placeholder="Edad"
        value={edad}
        onChange={(e) => setEdad(e.target.value)}
        style={{ marginRight: '10px' }}
      />
      <input
        type="text"
        placeholder="Ciclo"
        value={ciclo}
        onChange={(e) => setCiclo(e.target.value)}
        style={{ marginRight: '10px' }}
      />
      <input
        type="text"
        placeholder="Carrera"
        value={carrera}
        onChange={(e) => setCarrera(e.target.value)}
        style={{ marginRight: '10px' }}
      />
      <button type="submit">Agregar Estudiante</button>
    </form>
  );
};

export default FormularioEstudiante;
