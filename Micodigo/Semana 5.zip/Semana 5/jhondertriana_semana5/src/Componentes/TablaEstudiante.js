import React from 'react';

const TablaEstudiante = ({ estudiantes }) => {
  return (
    <table border="1" style={{ width: '100%', textAlign: 'left' }}>
      <thead>
        <tr>
          <th>Nombre</th>
          <th>Edad</th>
          <th>Ciclo</th>
          <th>Carrera</th>
        </tr>
      </thead>
      <tbody>
        {estudiantes.length > 0 ? (
          estudiantes.map((estudiante, index) => (
            <tr key={index}>
              <td>{estudiante.nombre}</td>
              <td>{estudiante.edad}</td>
              <td>{estudiante.ciclo}</td>
              <td>{estudiante.carrera}</td>
            </tr>
          ))
        ) : (
          <tr>
            <td colSpan="3">No hay estudiantes registrados.</td>
          </tr>
        )}
      </tbody>
    </table>
  );
};

export default TablaEstudiante;
