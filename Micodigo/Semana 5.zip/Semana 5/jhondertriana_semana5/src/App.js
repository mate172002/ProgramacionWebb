import React, { useState } from 'react';
import FormularioEstudiante from './Componentes/FormularioEstudiante';
import TablaEstudiante from './Componentes/TablaEstudiante';
import logo from './ImagenUIDE/logo-uide.png';
import './App.css'; 

const App = () => {
  const [estudiantes, setEstudiantes] = useState([]);

  // agregar un estudiante a la lista
  const addEstudiante = (estudiante) => {
    setEstudiantes([...estudiantes, estudiante]);
  };

  return (
    <div className="App" style={{ padding: '20px' }}>
      <h1>Registro de Estudiantes UIDE</h1>
      <img src={logo} alt="Logo UIDE" style={{ width: '200px', marginTop: '30px' }} />
      <FormularioEstudiante addEstudiante={addEstudiante} />
      <TablaEstudiante estudiantes={estudiantes} />
    </div>
  );
};

export default App;

